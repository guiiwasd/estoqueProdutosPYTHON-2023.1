from django.contrib import admin
from .models import Cores

class CoresAdmin(admin.ModelAdmin):
    list_display = ['cor']
admin.site.register(Cores, CoresAdmin)